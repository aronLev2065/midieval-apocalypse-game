# midieval-apocolypse-game
A PLATFORMER GAME, CREATED BY ME, ARONOV LEV, AS THE FIRST GAME PROJECT

To start the game install python, pip and pygame on your PC. Then run the game by launching the "main.py" file

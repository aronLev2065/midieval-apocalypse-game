<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="door tileset" tilewidth="256" tileheight="120" tilecount="5" columns="5">
 <image source="../../../assets/tiles/door.png" trans="000000" width="1280" height="120"/>
</tileset>

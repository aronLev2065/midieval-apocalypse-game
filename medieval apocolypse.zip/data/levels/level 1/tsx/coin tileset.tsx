<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="coin tileset" tilewidth="90" tileheight="90" tilecount="1" columns="1">
 <image source="../../../assets/tiles/coin.png" trans="000000" width="90" height="90"/>
</tileset>

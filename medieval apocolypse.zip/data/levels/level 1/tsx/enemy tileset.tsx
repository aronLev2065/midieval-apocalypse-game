<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="enemy tileset" tilewidth="90" tileheight="90" tilecount="4" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="90" height="72" source="../../../assets/enemies/enemy sprites/mushroom.png"/>
 </tile>
 <tile id="1">
  <image width="90" height="90" source="../../../assets/enemies/enemy sprites/skeleton.png"/>
 </tile>
 <tile id="2">
  <image width="90" height="72" source="../../../assets/enemies/enemy sprites/flying eye.png"/>
 </tile>
 <tile id="3">
  <image width="90" height="72" source="../../../assets/enemies/enemy sprites/goblin.png"/>
 </tile>
</tileset>

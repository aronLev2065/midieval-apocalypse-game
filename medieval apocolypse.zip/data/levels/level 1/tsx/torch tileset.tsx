<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="torch tileset" tilewidth="90" tileheight="90" tilecount="1" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="90" height="90" source="../../../assets/tiles/torch animations/Torch_64_Flamas_0.png"/>
 </tile>
</tileset>

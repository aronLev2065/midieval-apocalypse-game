<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="background tileset" tilewidth="90" tileheight="90" tilecount="50" columns="10">
 <image source="../../../assets/tiles/background tileset.png" trans="ffffff" width="900" height="450"/>
</tileset>

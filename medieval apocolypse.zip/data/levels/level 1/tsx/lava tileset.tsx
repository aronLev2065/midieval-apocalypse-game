<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="lava tileset" tilewidth="90" tileheight="90" tilecount="4" columns="4">
 <image source="../../../assets/tiles/lava animation.png" trans="ffffff" width="360" height="90"/>
</tileset>

<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="borders tileset" tilewidth="90" tileheight="90" tilecount="1" columns="1">
 <image source="../../../assets/enemies/enemy sprites/borders.bmp" trans="ffffff" width="90" height="90"/>
</tileset>
